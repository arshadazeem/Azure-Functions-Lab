﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InsuranceFuncApp
{
    class Vehicle
    {
        public String Year { get; set; }
        public String Make { get; set; }
        public String Model { get; set; }
    }
}

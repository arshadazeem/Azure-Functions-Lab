﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InsuranceFuncApp
{
    class VehicleQuoteRequest
    {
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public Vehicle Vehicle { get; set; }
    }
}
